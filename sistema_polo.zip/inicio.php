<?php
 include('menu.php');
 ?>

<div class="content_todoF">
<img class="img_fondo" src="ing_fondo.jpg" alt="">

</div>

  </body>
</html>
